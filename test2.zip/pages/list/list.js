// pages/list/list.js
Page({


  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    source:'',
    imgalist: ['http://111.230.62.94:8080/1.jpg']
  },

  previewImage: function (e) {
    var current = e.target.dataset.src;
    wx.previewImage({
      current: current, // 当前显示图片的http链接  
      urls: this.data.imgalist // 需要预览的图片http链接列表  
    })
  }    ,
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    wx.request({
      url: 'http://localhost:8080/wx/superadmin/listarea',
      method: 'GET',
      data: {},
      success: function (res) {
        var list = res.data.areaList;
        if (list == null) {
          var toastText = '获取数据失败' + res.data.errMsg;
          wx.showToast({
            title: toastText,
            icon: '',
            duration: 2000
          });
        } else {
          that.setData({
            list: list
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  addArea: function () {
    wx.navigateTo({
      url: '../operation/operation',
    })
  },

  deleteArea: function (e) {
    var that = this;
    wx.showModal({
      title: '提示',
      content: '确定要删除[' + e.target.dataset.areaname + ']吗？',
      success: function (sm) {
        if (sm.confirm) {
          wx.request({
            url: 'http://localhost:8080/wx/superadmin/removearea',
            data: { "areaId": e.target.dataset.areaid },
            method: 'GET',
            success: function (res) {
              var result = res.data.success;
              var toastText = "删除成功";
              if (result != true) {
                toastText = "删除失败";

              } else {
                that.data.list.splice(e.target.dataset.index, 1)
                that.setData({
                  list: that.data.list
                });
                // 利用传入的index将数组中的数据删除
              }
              wx.showToast({
                title: toastText,
                icon: '',
                duration: 2000
              });
            }
          })
        }
      }
    })
  },

  addFile: function (e) {
    wx.chooseImage({
      success: function (res) {
        var tempFilePaths = res.tempFilePaths
        wx.uploadFile({
          url: 'http://localhost:8080/wx/superadmin/uploadfile',
          filePath: tempFilePaths[0],
          name: 'file',
          formData: {
            'user': 'test',
            'type': '1'
          },
          success: function (res) {
            var success = res.data.result;
            var toastText;
            if (result == true) {
              toastText = "提交成功";
            } else {
              toastText = "提交失败";
            }
            wx.showToast({
              title: toastText,
              icon: '',
              duration: 200
            })
            //do something
          }
        })
      }
    })
  },

  checkUser: function () {
    wx.login({
      success: function (res) {
        if (res.code) {
          let url = config.HTTP_URL + '/v1/user/login';
          let data = {
            code: res.code
          }
          util.request(url, 'post', data, '正在加载数据'), 
          function (res) {
            console.log('登录接口返回结果：' + JSON.stringify(res.data))
            if (res.data.openid) {
              wx.setStorageSync('openid', res.data.openid)
            }
          }  
        } 
      }
    })    
  },


})